#!/bin/bash

src="$(dirname ${BASH_SOURCE[0]})"
src="$(cd "$src" && pwd)"

sudo apt-get install libftdi-dev libusb-dev dfu-programmer -y --force-yes

sh $src/configure --with-libftd2xx=$src/libftd2xx
make
sudo make install

sudo cp -rpf "$src/libftd2xx/build/x86_64/lib"* "/usr/local/lib/"
sudo cp      "$src/udev/rules.d/10-krypton-jtag.rules" "/etc/udev/rules.d/"
sudo cp      "$src/udev/rules.d/12-pt51-dfu.rules"     "/etc/udev/rules.d/"
sudo /etc/init.d/udev restart
sudo adduser student dialout
sudo adduser wel dialout
